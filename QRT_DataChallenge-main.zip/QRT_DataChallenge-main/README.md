# QRT_DataChallenge
 A 4 hours long challenge in team of 6. Guessing the winner of soccer matches, using a large scale dataset of football metrics. 
